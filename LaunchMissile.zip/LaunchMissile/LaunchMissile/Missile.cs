﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LaunchMissile
{
    public interface Missile
    {
        string getImpactRangeInKm();
        double getWeight();
        void setLocation(double Latitude, double Longitude);
        void launch();
        void startCountdown();
        void ejectMissile(double? lat,double? lon);
    }

   public class Missile_Mega2000 : Missile
    {
        string range;
        double weight;
        double? latitude =null;
        double? longitude =null;

        public Missile_Mega2000()
        {
            range = "5000Km";
            weight = 200.0;
        }
        public string getImpactRangeInKm()
        {
            return range;
        }

        public double getWeight()
        {
            return weight;
        }

        public virtual void launch()
        {
            if (coordinatesNotSet())
            {   
                Failure.TakeCorrespondingAction("coordinates are not set");
            }
            startCountdown();
            ejectMissile(latitude, longitude);
        }

        bool coordinatesNotSet()
        {
            if (!latitude.HasValue || !longitude.HasValue)
            {
                return true;
            }
            return false;
        }
        public void setLocation(double latitude, double longitude)
        {
            this.latitude = latitude;
            this.longitude = longitude;
        }

        public void startCountdown()
        {
            //display countdown until 10
        }

        public void ejectMissile(double? lat, double? lon)
        {
            //release it
        }
    }

}
