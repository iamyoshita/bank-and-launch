﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LaunchMissile
{
    public class MainProcess
    {
       public static void launchMissile(Missile missile, Credentials cred)
        {
            missile.launch();
        }
    }
    public class User
    {
        public bool giveAccess=false;
        public User(bool validuser)
        {
            if(validuser==true)
            giveAccess = true;
        }
    }
}
