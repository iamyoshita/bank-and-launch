﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LaunchMissile
{
    public class Credentials
    {
        string code;
        public Credentials()
        { }
        public void set(string str)
        {
           code = str;
        }

    }
}
