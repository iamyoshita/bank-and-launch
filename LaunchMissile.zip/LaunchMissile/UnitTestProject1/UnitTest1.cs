using Microsoft.VisualStudio.TestTools.UnitTesting;
using LaunchMissile;
namespace UnitTestProject1
{
    [TestClass]
    public class UnitTest1
    {
        [TestClass]//testing spy
        class MissileSpy : Missile_Mega2000
        {
            public bool launchWasCalled = false;

            public override void launch()
            {
                launchWasCalled = true;
            }

            public bool getlaunchWasCalled()
            {
                return launchWasCalled;
            }
        }

        [TestMethod]
        public void Test_CheckIfLaunchWasCalled()
        {
            MissileSpy mspy = new MissileSpy();
            Credentials Validcred = new Credentials();
            MainProcess.launchMissile(mspy, Validcred);
            Assert.IsTrue(mspy.getlaunchWasCalled());
        }

        [TestClass]//testng mock
        class MockCredential : Credentials
        {
            public bool disable = false;

            public MockCredential(string s)
            {
                if (s.Length < 4)
                    disable = true;
            }

            public void verifyIfDisableWasCalled()
            {
                Assert.IsTrue(disable);
            }
        }

        [TestMethod]
        public void Test_DisableCalledWhenCredentialNotValid()
        {
            MockCredential mc = new MockCredential("abc");
            mc.verifyIfDisableWasCalled();
        }
        [TestClass]//testing dummy
        public class Authorize
        {
            public static bool login(string name,string password)
            {
                return true;
            }
        }
        [TestMethod]
        public void Test_ifUserWorks()
        {
            User u = new User(Authorize.login("username", "password"));
            Assert.AreEqual(true, u.giveAccess);
        }


    }
}
