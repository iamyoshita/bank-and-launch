﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LaunchMissile
{
    class Failure
    {
        public static void TakeCorrespondingAction(string reason)
        {
            if (reason.Equals("coordinates are not set"))
            {
                //pop a notification to enter coordinates.
            }

        }
    }
}
